package com.example.tes_resepkita

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
